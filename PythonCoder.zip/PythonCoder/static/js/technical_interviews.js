document.addEventListener('DOMContentLoaded', function() {
    // Initialize syntax highlighting
    document.querySelectorAll('pre code').forEach((block) => {
        hljs.highlightElement(block);
    });
    
    // Run challenge buttons
    document.querySelectorAll('.run-challenge').forEach(button => {
        button.addEventListener('click', function() {
            const challengeId = this.getAttribute('data-challenge-id');
            const codeEditor = document.getElementById(challengeId);
            const code = codeEditor.value;
            
            // Extract challenge type and number
            const parts = challengeId.split('-');
            const type = parts[1];  // easy, medium, hard
            const number = parts[2]; // 1, 2, etc.
            
            const resultDiv = document.getElementById(`result-${type}-${number}`);
            const outputDiv = document.getElementById(`output-${type}-${number}`);
            
            // Show results section
            resultDiv.classList.remove('d-none');
            
            // Simulate code execution
            simulateExecution(code, type, number, outputDiv);
        });
    });
    
    // Show solution buttons
    document.querySelectorAll('.solution-btn').forEach(button => {
        button.addEventListener('click', function() {
            const solutionId = this.getAttribute('data-solution-id');
            const solutionDiv = document.getElementById(solutionId);
            
            if (solutionDiv.classList.contains('d-none')) {
                solutionDiv.classList.remove('d-none');
                this.innerHTML = '<i data-feather="eye-off" class="me-1"></i> Hide Solution';
            } else {
                solutionDiv.classList.add('d-none');
                this.innerHTML = '<i data-feather="eye" class="me-1"></i> Solution';
            }
            
            // Re-initialize feather icons
            feather.replace();
        });
    });
    
    // Save checklist progress
    document.getElementById('save-checklist').addEventListener('click', function() {
        // In a real application, this would save to the database
        const checkedItems = document.querySelectorAll('input[type="checkbox"]:checked').length;
        const totalItems = document.querySelectorAll('input[type="checkbox"]').length;
        
        alert(`Your interview preparation progress has been saved! (${checkedItems}/${totalItems} items completed)`);
    });
    
    // Function to simulate code execution
    function simulateExecution(code, type, number, outputDiv) {
        let output = "Running your code...\n\n";
        
        // Analyze the code to determine a response
        if (type === 'easy' && number === '1') {
            // Reverse String challenge
            if (code.includes('[::-1]') || code.includes('reversed')) {
                output += "Testing with 'Hello World'...\nOutput: 'dlroW olleH'\n\nAll test cases passed! Your solution is correct.";
            } else if (code.includes('return') && code.includes('for')) {
                output += "Testing with 'Hello World'...\nOutput: 'dlroW olleH'\n\nAll test cases passed! Your solution works, but consider using Python's string slicing ([::-1]) for a more concise solution.";
            } else {
                output += "Testing with 'Hello World'...\nOutput: None\n\nYour solution doesn't seem to be working correctly. Make sure you're returning the reversed string.";
            }
        } else if (type === 'easy' && number === '2') {
            // Two Sum challenge
            if (code.includes('dict') || code.includes('{}') && code.includes('return') && 
                code.includes('enumerate') && code.includes('in')) {
                output += "Testing with nums = [2, 7, 11, 15], target = 9...\nOutput: [0, 1]\n\nTesting with nums = [3, 2, 4], target = 6...\nOutput: [1, 2]\n\nAll test cases passed! Your solution is correct and efficient.";
            } else if (code.includes('for') && code.includes('range') && code.includes('return')) {
                output += "Testing with nums = [2, 7, 11, 15], target = 9...\nOutput: [0, 1]\n\nTesting with nums = [3, 2, 4], target = 6...\nOutput: [1, 2]\n\nAll test cases passed! Your solution works, but consider using a dictionary for improved time complexity.";
            } else {
                output += "Your solution doesn't seem to handle all test cases correctly. Make sure you're returning the correct indices.";
            }
        } else if (type === 'medium' && number === '1') {
            // Valid Parentheses challenge
            if (code.includes('stack') && code.includes('return') && 
                (code.includes('pop') || code.includes('append'))) {
                output += "Testing with '()'...\nOutput: True\n\nTesting with '()[]{}'...\nOutput: True\n\nTesting with '(]'...\nOutput: False\n\nAll test cases passed! Your solution is correct.";
            } else {
                output += "Your solution might not handle all test cases correctly. Consider using a stack data structure to track opening brackets.";
            }
        } else if (type === 'hard' && number === '1') {
            // LRU Cache challenge
            if (code.includes('OrderedDict') || (code.includes('class') && code.includes('def __init__') && 
                code.includes('def get') && code.includes('def put'))) {
                output += "Testing LRU Cache with capacity 2...\nput(1, 1), put(2, 2)\nget(1) returns: 1\nput(3, 3) - evicts key 2\nget(2) returns: -1 (not found)\nput(4, 4) - evicts key 1\nget(1) returns: -1 (not found)\nget(3) returns: 3\nget(4) returns: 4\n\nAll operations function correctly!";
            } else {
                output += "Your implementation doesn't seem to handle the LRU cache requirements correctly. Make sure you're keeping track of the least recently used items.";
            }
        }
        
        outputDiv.textContent = output;
    }
    
    // Add ability to track user progress
    const totalChallenges = document.querySelectorAll('.accordion-item').length;
    let solvedChallenges = 0;
    
    // Function to update progress whenever a challenge is completed
    function updateProgress() {
        // In a real app, this would be persisted to a database
        const progressPercentage = Math.round((solvedChallenges / totalChallenges) * 100);
        document.getElementById('progress-bar').style.width = `${progressPercentage}%`;
        document.getElementById('progress-bar').textContent = `${progressPercentage}%`;
        document.getElementById('challenges-count').textContent = `${solvedChallenges}/${totalChallenges}`;
    }
    
    // Mark a challenge as solved when the user gets a correct solution
    document.querySelectorAll('.run-challenge').forEach(button => {
        button.addEventListener('click', function() {
            const challengeId = this.getAttribute('data-challenge-id');
            const codeEditor = document.getElementById(challengeId);
            const code = codeEditor.value;
            
            // Extract challenge type and number
            const parts = challengeId.split('-');
            const type = parts[1];  // easy, medium, hard
            const number = parts[2]; // 1, 2, etc.
            
            // Check if the solution is correct (simplified version)
            if (type === 'easy' && number === '1' && (code.includes('[::-1]') || code.includes('reversed'))) {
                // Mark as solved if not already
                if (!this.hasAttribute('data-solved')) {
                    solvedChallenges++;
                    updateProgress();
                    this.setAttribute('data-solved', 'true');
                    
                    // Add a success badge to the accordion header
                    const header = document.querySelector(`#${type}Heading${number} button`);
                    if (header && !header.querySelector('.badge')) {
                        const badge = document.createElement('span');
                        badge.className = 'badge bg-success ms-2';
                        badge.innerHTML = 'Solved';
                        header.appendChild(badge);
                    }
                }
            } else if (type === 'easy' && number === '2' && 
                      (code.includes('dict') || code.includes('{}')) && 
                      code.includes('return') && code.includes('in')) {
                if (!this.hasAttribute('data-solved')) {
                    solvedChallenges++;
                    updateProgress();
                    this.setAttribute('data-solved', 'true');
                    
                    const header = document.querySelector(`#${type}Heading${number} button`);
                    if (header && !header.querySelector('.badge')) {
                        const badge = document.createElement('span');
                        badge.className = 'badge bg-success ms-2';
                        badge.innerHTML = 'Solved';
                        header.appendChild(badge);
                    }
                }
            } else if (type === 'medium' && number === '1' && 
                      code.includes('stack') && code.includes('return') && 
                      (code.includes('pop') || code.includes('append'))) {
                if (!this.hasAttribute('data-solved')) {
                    solvedChallenges++;
                    updateProgress();
                    this.setAttribute('data-solved', 'true');
                    
                    const header = document.querySelector(`#${type}Heading${number} button`);
                    if (header && !header.querySelector('.badge')) {
                        const badge = document.createElement('span');
                        badge.className = 'badge bg-success ms-2';
                        badge.innerHTML = 'Solved';
                        header.appendChild(badge);
                    }
                }
            } else if (type === 'hard' && number === '1' && 
                      (code.includes('OrderedDict') || 
                       (code.includes('class') && code.includes('def __init__') && 
                        code.includes('def get') && code.includes('def put')))) {
                if (!this.hasAttribute('data-solved')) {
                    solvedChallenges++;
                    updateProgress();
                    this.setAttribute('data-solved', 'true');
                    
                    const header = document.querySelector(`#${type}Heading${number} button`);
                    if (header && !header.querySelector('.badge')) {
                        const badge = document.createElement('span');
                        badge.className = 'badge bg-success ms-2';
                        badge.innerHTML = 'Solved';
                        header.appendChild(badge);
                    }
                }
            }
        });
    });
    
    // Initialize feather icons
    feather.replace();
});