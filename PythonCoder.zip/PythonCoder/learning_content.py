# This file contains all the learning content for the Python learning path application

# Learning paths structured by difficulty level
learning_paths = [
    {
        "level": "Beginner",
        "description": "Start your Python journey with the fundamentals",
        "topics": [
            {
                "title": "Python Basics",
                "description": "Learn the core syntax and concepts of Python",
                "subtopics": [
                    "Installing Python and setting up your environment",
                    "Variables, data types, and basic operations",
                    "Control flow: if statements, loops",
                    "Functions and modules",
                    "Basic data structures: lists, dictionaries, tuples, sets",
                    "File I/O operations"
                ],
                "time_estimate": "2-3 weeks",
                "resources": [
                    "Official Python Documentation",
                    "Automate the Boring Stuff with Python (Al Sweigart)",
                    "Python Crash Course (Eric Matthes)"
                ]
            },
            {
                "title": "Object-Oriented Programming",
                "description": "Learn how to structure your code using classes and objects",
                "subtopics": [
                    "Classes and objects",
                    "Inheritance and polymorphism",
                    "Encapsulation and abstraction",
                    "Magic methods",
                    "Property decorators"
                ],
                "time_estimate": "1-2 weeks",
                "resources": [
                    "Python OOP tutorials on Real Python",
                    "Object-Oriented Programming in Python (Michael H. Goldwasser)"
                ]
            },
            {
                "title": "Basic Error Handling",
                "description": "Learn to handle exceptions gracefully",
                "subtopics": [
                    "Try/except blocks",
                    "Raising exceptions",
                    "Custom exceptions",
                    "Finally clause",
                    "Context managers (with statement)"
                ],
                "time_estimate": "1 week",
                "resources": [
                    "Python Exception Handling Documentation",
                    "Effective Python (Brett Slatkin)"
                ]
            }
        ]
    },
    {
        "level": "Intermediate",
        "description": "Expand your Python knowledge with more advanced concepts",
        "topics": [
            {
                "title": "Advanced Python Features",
                "description": "Explore powerful Python features for more efficient code",
                "subtopics": [
                    "List comprehensions and generator expressions",
                    "Lambda functions",
                    "Map, filter, and reduce",
                    "Decorators",
                    "Iterators and generators",
                    "Context managers"
                ],
                "time_estimate": "2 weeks",
                "resources": [
                    "Fluent Python (Luciano Ramalho)",
                    "Python Cookbook (David Beazley)"
                ]
            },
            {
                "title": "Data Analysis with Python",
                "description": "Learn essential libraries for data analysis",
                "subtopics": [
                    "NumPy basics (arrays, vectorized operations)",
                    "Pandas fundamentals (DataFrames, Series)",
                    "Data cleaning and transformation",
                    "Data visualization with Matplotlib and Seaborn",
                    "Basic statistical analysis"
                ],
                "time_estimate": "3-4 weeks",
                "resources": [
                    "Python for Data Analysis (Wes McKinney)",
                    "Pandas Documentation",
                    "NumPy Documentation",
                    "Matplotlib and Seaborn tutorials"
                ]
            },
            {
                "title": "Web Development Basics",
                "description": "Build web applications using Flask",
                "subtopics": [
                    "Introduction to Flask",
                    "Routing and views",
                    "Templates with Jinja2",
                    "Forms and user input",
                    "Database integration with SQLAlchemy",
                    "RESTful API development"
                ],
                "time_estimate": "3-4 weeks",
                "resources": [
                    "Flask Documentation",
                    "Flask Web Development (Miguel Grinberg)",
                    "Flask Mega-Tutorial (Miguel Grinberg)"
                ]
            }
        ]
    },
    {
        "level": "Advanced",
        "description": "Master Python with advanced concepts and professional tools",
        "topics": [
            {
                "title": "Testing and Debugging",
                "description": "Ensure code quality through proper testing",
                "subtopics": [
                    "Unit testing with unittest and pytest",
                    "Test-driven development",
                    "Mocking and patching",
                    "Debugging techniques",
                    "Code profiling and optimization"
                ],
                "time_estimate": "2 weeks",
                "resources": [
                    "Python Testing with pytest (Brian Okken)",
                    "pytest Documentation",
                    "Debugging in Python Documentation"
                ]
            },
            {
                "title": "Version Control with Git",
                "description": "Learn essential Git skills for collaborative development",
                "subtopics": [
                    "Basic Git commands",
                    "Branching and merging",
                    "Pull requests",
                    "Conflict resolution",
                    "Working with GitHub/GitLab"
                ],
                "time_estimate": "1-2 weeks",
                "resources": [
                    "Pro Git Book (Scott Chacon)",
                    "Git Documentation",
                    "GitHub Learning Lab"
                ]
            },
            {
                "title": "Advanced Projects",
                "description": "Apply your skills to real-world projects",
                "subtopics": [
                    "Full-stack web applications",
                    "Data analysis and visualization projects",
                    "Automation scripts",
                    "API development",
                    "Machine learning basics"
                ],
                "time_estimate": "4-8 weeks",
                "resources": [
                    "Project ideas from GitHub",
                    "Kaggle competitions",
                    "HackerRank challenges"
                ]
            }
        ]
    }
]

# Projects structured by difficulty level
projects = [
    {
        "level": "Beginner",
        "projects": [
            {
                "title": "To-Do List Application",
                "description": "Build a simple command-line to-do list manager where users can add, remove, and view tasks.",
                "skills": ["basic syntax", "functions", "file I/O", "data structures"],
                "link": "https://github.com/topics/todo-app-python",
                "time_estimate": "2-3 days"
            },
            {
                "title": "Password Generator",
                "description": "Create a program that generates strong, random passwords with customizable options.",
                "skills": ["string manipulation", "random module", "functions", "user input"],
                "link": "https://github.com/topics/password-generator-python",
                "time_estimate": "1-2 days"
            },
            {
                "title": "Number Guessing Game",
                "description": "Develop a game where the computer picks a random number and the user tries to guess it.",
                "skills": ["random module", "loops", "conditionals", "user input"],
                "link": "https://github.com/topics/number-guessing-game-python",
                "time_estimate": "1 day"
            },
            {
                "title": "Text-based Adventure Game",
                "description": "Create a simple text-based adventure game with multiple paths and outcomes.",
                "skills": ["control flow", "functions", "dictionaries", "game logic"],
                "link": "https://github.com/topics/text-adventure-python",
                "time_estimate": "3-5 days"
            }
        ]
    },
    {
        "level": "Intermediate",
        "projects": [
            {
                "title": "Weather Application",
                "description": "Build an application that fetches and displays weather data using a public API.",
                "skills": ["API integration", "requests library", "JSON parsing", "error handling"],
                "link": "https://github.com/topics/weather-app-python",
                "time_estimate": "3-4 days"
            },
            {
                "title": "Personal Budget Tracker",
                "description": "Create an application to track income, expenses, and generate reports using pandas.",
                "skills": ["pandas", "data analysis", "matplotlib", "file I/O"],
                "link": "https://github.com/topics/budget-tracker-python",
                "time_estimate": "5-7 days"
            },
            {
                "title": "Web Scraper",
                "description": "Build a web scraper to extract and analyze data from websites.",
                "skills": ["BeautifulSoup/Scrapy", "requests", "data manipulation", "file output"],
                "link": "https://github.com/topics/web-scraper-python",
                "time_estimate": "4-6 days"
            },
            {
                "title": "Flask Blog",
                "description": "Develop a simple blog application with Flask, including user authentication and database storage.",
                "skills": ["Flask", "SQLAlchemy", "HTML/CSS", "Jinja2 templates"],
                "link": "https://github.com/topics/flask-blog",
                "time_estimate": "1-2 weeks"
            }
        ]
    },
    {
        "level": "Advanced",
        "projects": [
            {
                "title": "E-commerce API",
                "description": "Build a RESTful API for an e-commerce platform with authentication, product management, and order processing.",
                "skills": ["Flask/FastAPI", "RESTful design", "authentication", "database design"],
                "link": "https://github.com/topics/ecommerce-api-python",
                "time_estimate": "2-3 weeks"
            },
            {
                "title": "Data Analysis Dashboard",
                "description": "Create an interactive dashboard for data visualization and analysis with Dash or Streamlit.",
                "skills": ["pandas", "data visualization", "Dash/Streamlit", "statistical analysis"],
                "link": "https://github.com/topics/dashboard-python",
                "time_estimate": "1-2 weeks"
            },
            {
                "title": "Automated Testing Framework",
                "description": "Develop a comprehensive testing framework for a web application using pytest and Selenium.",
                "skills": ["pytest", "Selenium", "test automation", "continuous integration"],
                "link": "https://github.com/topics/test-automation-python",
                "time_estimate": "2 weeks"
            },
            {
                "title": "Machine Learning Recommendation System",
                "description": "Build a recommendation system for movies, books, or products using collaborative filtering.",
                "skills": ["scikit-learn", "pandas", "numpy", "machine learning basics"],
                "link": "https://github.com/topics/recommendation-system-python",
                "time_estimate": "2-3 weeks"
            }
        ]
    }
]

# Coding exercises by topic and difficulty
exercises = [
    {
        "topic": "Python Basics",
        "exercises": [
            {
                "title": "Variable Swap",
                "difficulty": "Easy",
                "description": "Write a function to swap the values of two variables without using a temporary variable.",
                "hint": "Consider using tuple unpacking"
            },
            {
                "title": "Temperature Converter",
                "difficulty": "Easy",
                "description": "Create a function that converts temperatures between Celsius and Fahrenheit.",
                "hint": "F = (C * 9/5) + 32"
            },
            {
                "title": "Prime Number Checker",
                "difficulty": "Medium",
                "description": "Write a function that checks if a given number is prime.",
                "hint": "A number is prime if it's only divisible by 1 and itself"
            },
            {
                "title": "Fibonacci Sequence",
                "difficulty": "Medium",
                "description": "Generate the first n numbers in the Fibonacci sequence.",
                "hint": "Each number is the sum of the two preceding ones"
            }
        ]
    },
    {
        "topic": "Data Structures",
        "exercises": [
            {
                "title": "List Comprehension Practice",
                "difficulty": "Easy",
                "description": "Convert a for loop that creates a list of squares into a list comprehension.",
                "hint": "List comprehensions follow the pattern [expression for item in iterable]"
            },
            {
                "title": "Dictionary Manipulation",
                "difficulty": "Medium",
                "description": "Create a function that merges two dictionaries and handles duplicate keys by keeping the larger value.",
                "hint": "You can iterate through the keys of one dictionary and check if they exist in the other"
            },
            {
                "title": "Custom Sorting",
                "difficulty": "Medium",
                "description": "Sort a list of dictionaries based on a specific key within each dictionary.",
                "hint": "Use the 'key' parameter in the sort() method or sorted() function"
            },
            {
                "title": "Finding Duplicates",
                "difficulty": "Hard",
                "description": "Write a function that finds all duplicates in a list with O(n) time complexity.",
                "hint": "Consider using a set or counter to track occurrences"
            }
        ]
    },
    {
        "topic": "Functions and OOP",
        "exercises": [
            {
                "title": "Function Recursion",
                "difficulty": "Medium",
                "description": "Implement a recursive function to calculate the factorial of a number.",
                "hint": "A factorial is the product of an integer and all integers below it"
            },
            {
                "title": "Decorator Creation",
                "difficulty": "Hard",
                "description": "Create a timing decorator that prints how long a function takes to execute.",
                "hint": "Use the time module to measure execution time"
            },
            {
                "title": "Class Inheritance",
                "difficulty": "Medium",
                "description": "Design a 'Vehicle' base class and create 'Car' and 'Motorcycle' subclasses with appropriate attributes and methods.",
                "hint": "Think about what attributes and methods all vehicles share versus specialized ones"
            },
            {
                "title": "Context Manager",
                "difficulty": "Hard",
                "description": "Implement a custom context manager for handling file operations with error logging.",
                "hint": "Implement __enter__ and __exit__ methods"
            }
        ]
    },
    {
        "topic": "Data Analysis",
        "exercises": [
            {
                "title": "Pandas DataFrame Filtering",
                "difficulty": "Medium",
                "description": "Filter a DataFrame to find all rows where a specific column meets multiple conditions.",
                "hint": "Use boolean indexing with logical operators"
            },
            {
                "title": "Data Aggregation",
                "difficulty": "Medium",
                "description": "Group a DataFrame by a category and calculate multiple aggregations on different columns.",
                "hint": "Use the groupby() and agg() methods"
            },
            {
                "title": "Time Series Analysis",
                "difficulty": "Hard",
                "description": "Resample a time series dataset to calculate moving averages over different periods.",
                "hint": "Use resample() and rolling() methods"
            },
            {
                "title": "Data Visualization",
                "difficulty": "Medium",
                "description": "Create a multi-panel figure showing different aspects of a dataset using matplotlib and seaborn.",
                "hint": "Use plt.subplots() to create multiple axes"
            }
        ]
    }
]

# Learning resources by category
resources = [
    {
        "category": "Documentation",
        "resources": [
            {
                "title": "Official Python Documentation",
                "url": "https://docs.python.org/3/",
                "description": "The official documentation for Python, including tutorials, library references, and guides."
            },
            {
                "title": "Real Python",
                "url": "https://realpython.com/",
                "description": "Comprehensive tutorials and articles on Python programming."
            },
            {
                "title": "Python Pandas Documentation",
                "url": "https://pandas.pydata.org/docs/",
                "description": "Official documentation for the pandas library."
            },
            {
                "title": "Flask Documentation",
                "url": "https://flask.palletsprojects.com/",
                "description": "Official documentation for the Flask web framework."
            }
        ]
    },
    {
        "category": "Books",
        "resources": [
            {
                "title": "Python Crash Course",
                "author": "Eric Matthes",
                "description": "A hands-on, project-based introduction to programming with Python."
            },
            {
                "title": "Automate the Boring Stuff with Python",
                "author": "Al Sweigart",
                "description": "Practical programming for total beginners."
            },
            {
                "title": "Fluent Python",
                "author": "Luciano Ramalho",
                "description": "Clear, concise, and effective programming patterns for Python."
            },
            {
                "title": "Python for Data Analysis",
                "author": "Wes McKinney",
                "description": "Data manipulation and analysis using Python's pandas library."
            }
        ]
    },
    {
        "category": "Online Courses",
        "resources": [
            {
                "title": "Python for Everybody",
                "platform": "Coursera",
                "url": "https://www.coursera.org/specializations/python",
                "description": "A specialization covering Python basics through data structures."
            },
            {
                "title": "Complete Python Bootcamp",
                "platform": "Udemy",
                "url": "https://www.udemy.com/course/complete-python-bootcamp/",
                "description": "Comprehensive Python programming course from basics to advanced topics."
            },
            {
                "title": "CS50's Introduction to Programming with Python",
                "platform": "edX",
                "url": "https://www.edx.org/course/cs50s-introduction-to-programming-with-python",
                "description": "Harvard's introduction to programming using Python."
            },
            {
                "title": "Python Data Science Handbook",
                "platform": "GitHub",
                "url": "https://jakevdp.github.io/PythonDataScienceHandbook/",
                "description": "Free online book covering the entire data science workflow with Python."
            }
        ]
    },
    {
        "category": "Practice Platforms",
        "resources": [
            {
                "title": "LeetCode",
                "url": "https://leetcode.com/",
                "description": "Platform for practicing algorithmic problems, often used in technical interviews."
            },
            {
                "title": "HackerRank",
                "url": "https://www.hackerrank.com/domains/python",
                "description": "Python challenges from basic to advanced levels with automated testing."
            },
            {
                "title": "Codewars",
                "url": "https://www.codewars.com/",
                "description": "Improve your skills by training with others on code challenges called 'kata'."
            },
            {
                "title": "Exercism",
                "url": "https://exercism.io/tracks/python",
                "description": "Free coding exercises with mentorship and real-world projects."
            }
        ]
    }
]

# Job skills and roles using Python
job_skills = [
    {
        "role": "Python Developer",
        "description": "General Python development for applications, scripts, and tools",
        "required_skills": [
            "Strong Python fundamentals",
            "Object-oriented programming",
            "Database knowledge (SQL/NoSQL)",
            "Version control (Git)",
            "Testing and debugging",
            "Basic web development concepts"
        ],
        "recommended_path": "Start with Python fundamentals, move to intermediate concepts, then focus on application development with frameworks like Flask or Django.",
        "sample_projects": [
            "Web applications using Flask/Django",
            "Command-line utilities",
            "API integrations",
            "Automation scripts"
        ],
        "job_outlook": "Strong demand across industries, with average salary ranges of $80,000-$120,000 depending on experience and location."
    },
    {
        "role": "Data Analyst",
        "description": "Analyze data to extract insights and support decision-making",
        "required_skills": [
            "Python fundamentals",
            "Data manipulation with pandas",
            "Data visualization (matplotlib, seaborn)",
            "SQL",
            "Statistical analysis",
            "Data cleaning and preprocessing",
            "Business intelligence tools (optional)"
        ],
        "recommended_path": "Learn Python basics, then focus heavily on data analysis libraries (pandas, numpy), visualization tools, and statistical methods.",
        "sample_projects": [
            "Exploratory data analysis on real datasets",
            "Interactive dashboards",
            "Data cleaning pipelines",
            "Statistical analysis reports"
        ],
        "job_outlook": "High demand in virtually all industries, with average salary ranges of $70,000-$110,000."
    },
    {
        "role": "Data Scientist",
        "description": "Build predictive models and extract deeper insights from data",
        "required_skills": [
            "Strong Python programming",
            "Data manipulation with pandas",
            "Machine learning (scikit-learn)",
            "Statistics and probability",
            "Data visualization",
            "SQL",
            "Basic understanding of deep learning concepts"
        ],
        "recommended_path": "Start with Python and data analysis fundamentals, then progress to machine learning algorithms, model evaluation, and deployment.",
        "sample_projects": [
            "Predictive modeling projects",
            "Classification and regression models",
            "Clustering and pattern recognition",
            "Time series forecasting"
        ],
        "job_outlook": "Very high demand with strong growth prospects, average salary ranges of $90,000-$150,000+."
    },
    {
        "role": "Backend Developer",
        "description": "Develop server-side logic and APIs for web applications",
        "required_skills": [
            "Python programming",
            "Web frameworks (Flask, Django, FastAPI)",
            "Database design and ORM usage",
            "RESTful API development",
            "Authentication and security",
            "Testing and debugging",
            "Version control"
        ],
        "recommended_path": "Learn Python fundamentals, then focus on web frameworks, API design, databases, and deployment strategies.",
        "sample_projects": [
            "RESTful API services",
            "Content management systems",
            "E-commerce backends",
            "Authentication systems"
        ],
        "job_outlook": "Strong demand in software companies and tech startups, with average salary ranges of $85,000-$130,000."
    },
    {
        "role": "DevOps Engineer",
        "description": "Automate infrastructure and deployment processes",
        "required_skills": [
            "Python scripting",
            "Infrastructure as Code",
            "CI/CD pipelines",
            "Cloud platforms (AWS, Azure, GCP)",
            "Containerization (Docker)",
            "Monitoring and logging",
            "Bash scripting"
        ],
        "recommended_path": "Learn Python basics with a focus on scripting, then study infrastructure automation, cloud services, and monitoring systems.",
        "sample_projects": [
            "Automated deployment scripts",
            "Infrastructure provisioning tools",
            "Monitoring dashboards",
            "Log analysis utilities"
        ],
        "job_outlook": "Very high demand with excellent compensation, average salary ranges of $95,000-$140,000+."
    },
    {
        "role": "Quality Assurance / Test Engineer",
        "description": "Automate testing processes and ensure software quality",
        "required_skills": [
            "Python programming",
            "Test automation frameworks (pytest, unittest)",
            "Selenium for UI testing",
            "API testing",
            "CI/CD integration",
            "Bug tracking and documentation"
        ],
        "recommended_path": "Learn Python basics, then focus on testing methodologies, automation frameworks, and quality assurance processes.",
        "sample_projects": [
            "Automated test suites",
            "API testing frameworks",
            "UI test automation",
            "Performance testing tools"
        ],
        "job_outlook": "Steady demand in software development companies, with average salary ranges of $75,000-$115,000."
    }
]
